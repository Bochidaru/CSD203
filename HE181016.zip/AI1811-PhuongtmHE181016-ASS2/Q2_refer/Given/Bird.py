class Bird:
    def __init__(self, xType="", xRate=-1, xWing=-1):
        self.type = xType
        self.rate = xRate
        self.wing = xWing

    def __repr__(self):
        return f"({self.type},{self.rate},{self.wing})"

class BSTree:
    def __init__(self):
        self.root = None

    def f0(self):
        return "He181016"

    def insert(self, xType, xRate, xWing):
        if xType[0] == 'B' or xRate > 10:
            return
        new_bird = Bird(xType, xRate, xWing)
        if self.root is None:
            self.root = new_bird
        else:
            self._insert_helper(self.root, new_bird)

    def _insert_helper(self, current, new_bird):
        if new_bird.rate < current.rate:
            if current.left is None:
                current.left = new_bird
            else:
                self._insert_helper(current.left, new_bird)
        else:
            if current.right is None:
                current.right = new_bird
            else:
                self._insert_helper(current.right, new_bird)

    def f1(self):
        # Method f1 only requires completion of the insert method, already implemented.
        pass

    def f2(self):
        self._preorder_wing_in_range(self.root, 4, 10)

    def _preorder_wing_in_range(self, node, low, high):
        if node:
            if low <= node.wing <= high:
                print(node, end=" ")
            self._preorder_wing_in_range(node.left, low, high)
            self._preorder_wing_in_range(node.right, low, high)

    def f3(self):
        if self.root is None:
            return
        queue = [self.root]
        odd_position = True
        while queue:
            size = len(queue)
            for i in range(size):
                current = queue.pop(0)
                if odd_position:
                    print(current, end=" ")
                if current.left:
                    queue.append(current.left)
                if current.right:
                    queue.append(current.right)
            odd_position = not odd_position

    def f4(self):
        self._postorder_wings_greater_than(self.root, 6, 4)

    def _postorder_wings_greater_than(self, node, rate_threshold, wing_threshold):
        if node:
            self._postorder_wings_greater_than(node.left, rate_threshold, wing_threshold)
            self._postorder_wings_greater_than(node.right, rate_threshold, wing_threshold)
            if node.wing <= wing_threshold and node.rate > rate_threshold:
                print(node, end=" ")

    def f5(self):
        self._inorder_type_start_with(self.root, 'A', 'C')

    def _inorder_type_start_with(self, node, start1, start2):
        if node:
            self._inorder_type_start_with(node.left, start1, start2)
            if node.type[0] == start1 or node.type[0] == start2:
                print(node, end=" ")
            self._inorder_type_start_with(node.right, start1, start2)

    def f6(self):
        pass

    def f7(self):
        pass

    def f8(self):
        pass

    def f9(self):
        pass

    def f10(self):
        pass

    def f11(self):
        pass
